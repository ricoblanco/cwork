#!/bin/bash
echo "start"
range=120
min_vala=60
rangea=80
PROG="PRGX"
START=1
while true ; do
    if [[ START -ne 1 ]]; then
      sleepsc1=$[ ( $RANDOM % $rangea ) + $min_vala ]
      echo "wait $sleepsc1 seconds"
      sleep $sleepsc1
    fi
    nohup ./$PROG --config=x.json &
    last_pid=$!
    echo $last_pid
    WORK_TIME=`cat time.txt`
    min_val=$WORK_TIME
    sleepsec=$[ ( $RANDOM % $range ) + $min_val ]
    echo "working for $sleepsec"
    sleep $sleepsec
    cat nohup.out
    kill -KILL $last_pid
    echo "killed worker"
    START=0
done
